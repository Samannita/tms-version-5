
package com.cg.trainingmanagementystem.services;

import com.cg.trainingmanagementystem.service.bean.Student;

public class StudentService {

	public StudentService() {
	}

	public boolean giveFeedback(Student student) {
		// TODO implement here
		return false;
	}

}
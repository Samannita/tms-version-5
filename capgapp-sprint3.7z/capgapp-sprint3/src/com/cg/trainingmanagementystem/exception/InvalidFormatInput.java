package com.cg.trainingmanagementystem.exception;

public class InvalidFormatInput extends Exception {

	//private static final long serialVersionUID = 1L;

	public InvalidFormatInput(String msg) {
		super(msg);
	}

}

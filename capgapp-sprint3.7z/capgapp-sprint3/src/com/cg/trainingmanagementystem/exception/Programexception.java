package com.cg.trainingmanagementystem.exception;

public class Programexception extends Exception {
	public Programexception(String errorMessages) {
		super(errorMessages);
	}

}

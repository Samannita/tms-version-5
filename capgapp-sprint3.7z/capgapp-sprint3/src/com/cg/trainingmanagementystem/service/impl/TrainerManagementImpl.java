package com.cg.trainingmanagementystem.service.impl;

import java.util.*;

import com.cg.trainingmanagementystem.service.ITrainerManagement;
import com.cg.trainingmanagementystem.service.bean.Trainer;
import com.cg.trainingmanagementystem.service.enumv.Skills;

/**
 * 
 */
public class TrainerManagementImpl implements ITrainerManagement {

	@Override
	public boolean addSkillsToTrainer(String trainerId, Skills skill) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delSkillsToTrainer(String trainerId, Skills skills) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Trainer getTrainerDetails(Trainer trainer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashSet<Trainer> getAllTrainers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createTrainer(Trainer trainer) {
		// TODO Auto-generated method stub
		return false;
	}


}
package com.cg.trainingmanagementystem.service.enumv;

public enum Skills {

}

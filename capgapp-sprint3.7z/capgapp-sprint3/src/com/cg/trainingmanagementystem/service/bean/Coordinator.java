package com.cg.trainingmanagementystem.service.bean;

public class Coordinator extends Employee {
	private Center center;
	/**
	 * Default constructor
	 */
	public Coordinator() {
	}

	/**
	 * 
	 */
	

}
package com.cg.trainingmanagementystem.service.bean;

import java.util.*;

/**
 * 
 */
public class TrainingProgram {

	/**
	 * Default constructor
	 */
	public TrainingProgram() {
	}

	/**
	 * 
	 */
	private String trainingId;

	/**
	 * 
	 */
	private Date trainingStartDate;

	/**
	 * 
	 */
	private Course course;

	/**
	 * 
	 */
	private Trainer trainer;

	/**
	 * 
	 */
	private Center center;

	/**
	 * 
	 */
	private Coordinator coordinator;


}
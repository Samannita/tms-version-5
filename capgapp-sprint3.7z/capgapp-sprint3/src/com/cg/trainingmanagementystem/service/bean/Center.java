package com.cg.trainingmanagementystem.service.bean;

public class Center {

	/**
	 * Default constructor
	 */
	public Center() {
	}

	/**
	 * 
	 */
	public String centerId;

	/**
	 * 
	 */
	public String centerName;

	/**
	 * 
	 */
	public String centerAddress;

}
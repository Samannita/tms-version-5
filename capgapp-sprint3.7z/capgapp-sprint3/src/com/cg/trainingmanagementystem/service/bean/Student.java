package com.cg.trainingmanagementystem.service.bean;

import java.util.*;

/**
 * 
 */
public class Student {

	/**
	 * Default constructor
	 */
	public Student() {
	}

	/**
	 * 
	 */
	private String studentId;

	/**
	 * 
	 */
	private String studentName;

	/**
	 * 
	 */
	private TrainingProgram trainingProgram;


}